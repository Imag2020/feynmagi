tools = { 
'google' : 'google\ne.g google : query_to_search_on_google_home_page\nsearch on google home page',
'weblinks' : 'weblinks\ne.g weblinks : query to search the relevent links from google\ngather links urls for related query',
'scrap' : 'scrap\ne.g scrap : url\nuse to get page content',
'write_to_file' : 'write_to_file\ne.g write-to-file : "file": "<file_name>", "text": "<text to write to file>"\nwrite information to a file',
'display_file' : 'display_file\ne.g display-file : file_name\ndisplay the content of a file to user output',
'dev_code' : 'dev_code\ne.g dev-code : "objective" : "<objective of the code>", "language": "<language>", "framework": "<framework>", "file_name" : "<file_name>" \nenerate simple module code to achieve an elementary task',
'execute_code' : 'execute_code\ne.g execute-code :  "file_name" : "<file_name>", "input": "<input data>", "environment": "<environment>"\nexcute code in file',
'calculate' : 'calculate\ne.g. calculate: 4 * 7 / 3\nRuns a calculation and returns the number - uses Python so be sure to use floating point syntax if necessary',
'get_planet_mass' : 'get_planet_mass:\ne.g. get_planet_mass: Earth\nreturns weight of the planet in kg',
'email' : 'email\ne.g email : "to" : "user@domain.com", "subject" : "subject", "body" : "text or html code", "attachment_path" : "(optional) path to file"\nSend an email"'
}