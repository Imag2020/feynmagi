# This is a simple Python script that prints 'Hello, World!'

# The print() function is used to display output on the screen
print("Hello, World!")