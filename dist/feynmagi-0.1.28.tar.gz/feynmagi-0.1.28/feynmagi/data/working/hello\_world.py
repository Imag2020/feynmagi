# This is a simple Python script to print 'Hello'

# The 'print()' function is used to display output on the screen
print('Hello')